package com.example.JwtAuthentication.Controller;

import com.example.JwtAuthentication.Models.User;
import com.example.JwtAuthentication.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.util.List;

@RestController
@RequestMapping("/home")
public class HomeController
{
    @Autowired
    private UserService userService;

    @GetMapping("/getusers")
    public List<User> getusers()
    {
        return userService.getusers();
    }

    @GetMapping("/current-user")
    public String getcurentuser(Principal principal)
    {
        return principal.getName();
    }
}

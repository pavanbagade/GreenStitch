package com.example.JwtAuthentication.Services;

import com.example.JwtAuthentication.Models.User;
import com.example.JwtAuthentication.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class UserService
{
    @Autowired
    UserRepository userRepository;
    List<User> store=new ArrayList<>();

    public UserService() {
        store.add(new User("Pavan","abc","pavan@email"));
    }

    public List<User> getusers()
    {
        return userRepository.findAll();
    }
}

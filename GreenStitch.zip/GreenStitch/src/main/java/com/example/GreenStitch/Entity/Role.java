package com.example.GreenStitch.Entity;

public enum Role {
    USER
}

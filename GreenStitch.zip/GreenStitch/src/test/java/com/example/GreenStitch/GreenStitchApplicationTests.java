package com.example.GreenStitch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenStitchApplicationTests {

	@Test
	void contextLoads() {
	}

}
